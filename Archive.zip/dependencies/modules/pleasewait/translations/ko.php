<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = '기다려주십시오 ...!';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = '웹 사이트를로드하는 동안로드 아이콘 표시';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = '로드 아이콘 사용';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = '로드 중 아이콘 유형';
$_MODULE['<{pleasewait}prestashop>pleasewait_254f642527b45bc260048e30704edb39'] = '구성';
$_MODULE['<{pleasewait}prestashop>pleasewait_c9cc8cce247e49bae79f15173ce97354'] = '구하다';
$_MODULE['<{pleasewait}prestashop>pleasewait_93cba07454f06a4a960172bbd6e2a435'] = '예';
$_MODULE['<{pleasewait}prestashop>pleasewait_bafd7322c6e97d25b6299b5d6fe8920b'] = '아니';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = '모든로드 아이콘 유형보기';
