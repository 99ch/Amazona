<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = 'お待ちください...！';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = 'ウェブサイトの読み込み中に読み込みアイコンを表示する';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = '読み込みアイコンを有効にする';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = 'アイコンタイプを読み込む';
$_MODULE['<{pleasewait}prestashop>pleasewait_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'メッセージ';
$_MODULE['<{pleasewait}prestashop>pleasewait_fa69ac6795d55bd7a44fe47ae4a7a854'] = 'ホームページのみで表示';
$_MODULE['<{pleasewait}prestashop>pleasewait_254f642527b45bc260048e30704edb39'] = '構成';
$_MODULE['<{pleasewait}prestashop>pleasewait_c9cc8cce247e49bae79f15173ce97354'] = 'セーブ';
$_MODULE['<{pleasewait}prestashop>pleasewait_93cba07454f06a4a960172bbd6e2a435'] = 'はい';
$_MODULE['<{pleasewait}prestashop>pleasewait_bafd7322c6e97d25b6299b5d6fe8920b'] = 'いいえ';
$_MODULE['<{pleasewait}prestashop>pleasewait_7cc92687130ea12abb80556681538001'] = '画像のアップロード処理中にエラーが発生しました。';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = 'すべての読み込みアイコンの種類を表示';
