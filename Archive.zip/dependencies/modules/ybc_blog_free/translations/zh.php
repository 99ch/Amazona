<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_59526bf44608558c7a7331e99f4b8038'] = '最新帖子';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_53eef1dc1c84ebd17d645173b7b7655a'] = '搜索：';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_59526bf44608558c7a7331e99f4b8038'] = '最新帖子';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_53eef1dc1c84ebd17d645173b7b7655a'] = '搜索：';
